﻿namespace SampleSolution.WebApi.Model
{
    public class Cars
    {
        public int CarsId { get; set; }
        public string Model { get; set; }
        public decimal RetailValue { get; set; }
        public DateTime DateManufactured { get; set; }
        public int TopSpeed { get; set; }
    }
}
