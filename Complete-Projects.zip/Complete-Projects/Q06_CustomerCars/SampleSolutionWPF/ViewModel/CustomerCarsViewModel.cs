﻿using Newtonsoft.Json;
using SampleSolutionWPF.Models;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;

namespace SampleSolutionWPF.ViewModel
{
    public class CustomerCarsViewModel : BaseClient
    {
        public ObservableCollection<CustomersModel> Customers { get; set; }
        private CustomersModel _selectedCustomer;
        public event PropertyChangedEventHandler PropertyChanged;

        public CustomersModel SelectedCustomer
        {
            get => _selectedCustomer;
            set
            {
                _selectedCustomer = value;
                OnPropertyChanged(nameof(SelectedCustomer));
                LoadCarDetails();
            }
        }

        private ObservableCollection<CarsModel> _customerCars;
        public ObservableCollection<CarsModel> CustomerCars
        {
            get => _customerCars;
            set
            {
                _customerCars = value;
                OnPropertyChanged(nameof(CustomerCars));
            }
        }

        public CustomerCarsViewModel()
        {
            Customers = new ObservableCollection<CustomersModel>();
            CustomerCars = new ObservableCollection<CarsModel>();
            LoadCustomerDetails();
        }

        public async Task LoadCustomerDetails()
        {
            try
            {
                var jsonResponse = await client.GetStringAsync("customercars");
                var customersList = JsonConvert.DeserializeObject<ObservableCollection<CustomersModel>>(jsonResponse);

                if (string.IsNullOrEmpty(jsonResponse))
                {
                    throw new InvalidOperationException("Received an empty response from the API.");
                }

                if (customersList == null)
                {
                    throw new InvalidOperationException("Failed to deserialize the response into the expected format.");
                }

                // Use Dispatcher to ensure changes happen on the UI thread
                Application.Current.Dispatcher.Invoke(() =>
                {
                    Customers.Clear();
                    foreach (var customer in customersList)
                    {
                        Customers.Add(customer);
                    }
                });
            }
            catch (HttpRequestException ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error fetching customers: {ex.Message}");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Unexpected error: {ex.Message}");
            }
        }

        private void LoadCarDetails()
        {
            if (SelectedCustomer != null)
            {
                // Use Dispatcher to ensure changes happen on the UI thread
                Application.Current.Dispatcher.Invoke(() =>
                {
                    CustomerCars = new ObservableCollection<CarsModel>(SelectedCustomer.Cars);
                });
            }
            else
            {
                CustomerCars.Clear();
            }
        }
    }
}
