﻿using System;
using System.IO;
using System.Xml.Linq;
using System.Globalization;

namespace Q04_XML
{
    class Program
    {
        static void Main(string[] args)
        {
            PopulateData();
        }

        //This function must list all the character Names and their Age
        //Use the sample.xml file in this project to get the information
        //Final result must be 4 rows/lines
        // Example Row Format: Name (Age)
        private static void PopulateData()
        {
            var xml = new StreamReader("sample.xml").ReadToEnd();

            var xDoc = XDocument.Parse(xml);

            // Get the current date to calculate age
            DateTime currentDate = DateTime.Now;

            // Loop through each "character" element
            foreach (var character in xDoc.Descendants("character"))
            {
                var name = character.Element("name")?.Value;
                var birthDate = character.Element("born")?.Value;

               
                if (DateTime.TryParseExact(birthDate, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime birthDateTime))
                {
                    // Calculate the age based on the birth date
                    int age = currentDate.Year - birthDateTime.Year;
                    if (currentDate < birthDateTime.AddYears(age)) age--;

                    // Display the result in the format: Name (Age)
                    Console.WriteLine($"{name} ({age})");
                }
            }

            Console.ReadKey();
        }
    }
}