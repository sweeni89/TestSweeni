﻿using SampleSolutionWPF.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SampleSolutionWPF.View
{
    /// <summary>
    /// Interaction logic for CustomerCars.xaml
    /// </summary>
    public partial class CustomerCars : Window
    {
        private readonly CustomerCarsViewModel _viewModel;
        public CustomerCars()
        {
            InitializeComponent();
            _viewModel = new CustomerCarsViewModel();
            DataContext = _viewModel;


            // Load API data asynchronously
            Task.Run(async () => await _viewModel.LoadCustomerDetails());
        }

      
    }
}
