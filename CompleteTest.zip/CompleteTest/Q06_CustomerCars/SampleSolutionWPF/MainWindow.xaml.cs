﻿using Newtonsoft.Json;
using SampleSolutionWPF.View;
using System.Net.Http;
using System.Text.Json.Serialization;
using System.Windows;
using System.Windows.Navigation;

namespace SampleSolutionWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        HttpClient client = new HttpClient();
        public MainWindow()
        {
            //client.BaseAddress = new Uri("https://localhost:44318/api/");
            //client.DefaultRequestHeaders.Accept.Clear();
            //client.DefaultRequestHeaders.Accept.Add(
            //    new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json")
            //    );
            InitializeComponent();
        }

      
    }
}