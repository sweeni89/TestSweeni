﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SampleSolution.WebApi.Context;
using SampleSolution.WebApi.Model;

namespace SampleSolution.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarsController : ControllerBase
    {
        private readonly SampleDbContext _sampleDbContext;

        public CarsController(SampleDbContext sampleDbContext)
        {
            _sampleDbContext = sampleDbContext;
        }


        // GET: api/Cars
        [HttpGet]
        public IEnumerable<Cars> GetCars()
        {
            return _sampleDbContext.Cars;
        }
    }
}
