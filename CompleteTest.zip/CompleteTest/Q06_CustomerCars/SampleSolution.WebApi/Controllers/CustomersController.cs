﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SampleSolution.WebApi.Context;
using SampleSolution.WebApi.Model;

namespace SampleSolution.WebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CustomersController : ControllerBase
    {     
       // private readonly ILogger<CustomersController> _logger;
        private readonly SampleDbContext _sampleDbContext;
        public CustomersController(SampleDbContext sampleDbContext)
        {
            _sampleDbContext = sampleDbContext;
        }


        // GET: api/Customers
        [HttpGet]
        public IEnumerable<Customers> Get()
        {
            return _sampleDbContext.Customers;
        }

    }
}
