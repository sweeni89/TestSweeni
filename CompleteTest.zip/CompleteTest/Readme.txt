Customer Cars System

1. CustomerCars database script in the "CustomerCars DataBase" Folder.

2.Customer Cars Completed system screen shots and screen recordings are available in the 'CustomerCars System ScreenShots' Folder

3. SampleSolution set multiple start up project.(SampleSolution.Webapi and SampleSolutionwpf)

4. You have to change the database connection string in SampleDbContext.cs

5. You have to change the BaseAddress in BaseClient.cs