﻿using System;

namespace Q01_ErrorHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int a = 10;
                int b = 0;
                int c = a / b;

                Console.WriteLine(c);
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Error: Division by zero is not allowed.");
                Console.WriteLine("Exception Details: " + ex.Message);
            }
            finally
            {
                Console.WriteLine("Execution completed.");
            }

            Console.ReadKey();
        }
    }
}
