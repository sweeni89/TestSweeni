﻿using System;
using System.Collections.Generic;

namespace Q05_Inheritance
{
    public abstract class Account
    {
        // Properties
        public string ClientNumber { get; set; }
        public string AccountNumber { get; set; }
        public decimal Balance { get; set; }

        // Method to print details
        public virtual void PrintDetails()
        {
            Console.WriteLine($"Client Number: {ClientNumber}");
            Console.WriteLine($"Account Number: {AccountNumber}");
            Console.WriteLine($"Balance: {Balance}");
        }
    }

    public class IndividualAccount : Account
    {
        // Additional properties specific to IndividualAccount
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string IdNumber { get; set; }

        // Override PrintDetails() to include both inherited and specific properties
        public override void PrintDetails()
        {
            base.PrintDetails(); // Print inherited properties
            Console.WriteLine($"First Name: {FirstName}");
            Console.WriteLine($"Surname: {Surname}");
            Console.WriteLine($"ID Number: {IdNumber}");
        }
    }

    public class CorporateAccount : Account
    {
        // Additional properties specific to CorporateAccount
        public string CompanyName { get; set; }
        public string CompanyRegNo { get; set; }

        // Override PrintDetails() to include both inherited and specific properties
        public override void PrintDetails()
        {
            base.PrintDetails(); // Print inherited properties
            Console.WriteLine($"Company Name: {CompanyName}");
            Console.WriteLine($"Company Registration Number: {CompanyRegNo}");
        }
    }

    public class Program
    {
        public static void Main()
        {
            // Instantiate IndividualAccount and CorporateAccount
            IndividualAccount individualAccount = new IndividualAccount
            {
                ClientNumber = "CLI12345",
                AccountNumber = "AN1234567",
                Balance = 10000.00M,
                FirstName = "Sweeni",
                Surname = "Sathivel",
                IdNumber = "ID123456789"
            };

            CorporateAccount corporateAccount = new CorporateAccount
            {
                ClientNumber = "CLCP98765",
                AccountNumber = "ANC123456",
                Balance = 50000.00M,
                CompanyName = "ABCD",
                CompanyRegNo = "REG123456"
            };

            // Add them to a list
            List<Account> accounts = new List<Account> { individualAccount, corporateAccount };

            // Loop through the list and call PrintDetails() for each account
            foreach (var account in accounts)
            {
                account.PrintDetails();
                Console.WriteLine(); // Print a newline between accounts for better readability
            }
        }
    }
}