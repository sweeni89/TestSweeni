﻿using System;
using System.ComponentModel;

namespace SampleSolutionWPF.Models
{
    public class CarsModel : INotifyPropertyChanged
    {
        private int _carsId;
        private string _model;
        private decimal _retailValue;
        private DateTime _dateManufactured;
        private int _topSpeed;

        public int CarsId
        {
            get => _carsId;
            set
            {
                _carsId = value;
                OnPropertyChanged(nameof(CarsId));
            }
        }

        public string Model
        {
            get => _model;
            set
            {
                _model = value;
                OnPropertyChanged(nameof(Model));
            }
        }

        public decimal RetailValue
        {
            get => _retailValue;
            set
            {
                _retailValue = value;
                OnPropertyChanged(nameof(RetailValue));
            }
        }

        public DateTime DateManufactured
        {
            get => _dateManufactured;
            set
            {
                _dateManufactured = value;
                OnPropertyChanged(nameof(DateManufactured));
            }
        }

        public int TopSpeed
        {
            get => _topSpeed;
            set
            {
                _topSpeed = value;
                OnPropertyChanged(nameof(TopSpeed));
            }
        }

        public string IdNumber { get; set; }
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
