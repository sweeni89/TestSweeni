﻿using System.ComponentModel;

namespace SampleSolutionWPF.Models
{
    public class CustomersModel : INotifyPropertyChanged
    {
        private int _customersId;
        private string _firstName;
        private string _lastName;
        private string _idNumber;
        private string _fullname;


        public int CustomersId
        {
            get => _customersId;
            set
            {
                _customersId = value;
                OnPropertyChanged(nameof(CustomersId));
            }
        }

        public string FirstName
        {
            get => _firstName;
            set
            {
                _firstName = value;
                OnPropertyChanged(nameof(FirstName));
            }
        }

        public string LastName
        {
            get => _lastName;
            set
            {
                _lastName = value;
                OnPropertyChanged(nameof(LastName));
            }
        }

        public string IdNumber
        {
            get => _idNumber;
            set
            {
                _idNumber = value;
                OnPropertyChanged(nameof(IdNumber));
            }
        }

        public string FullName
        { 
             get => _fullname;
            set
            {
                _fullname = value;
                OnPropertyChanged(nameof(FullName));
            }
        }
    public List<CarsModel> Cars { get; set; } = new();
       


        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
