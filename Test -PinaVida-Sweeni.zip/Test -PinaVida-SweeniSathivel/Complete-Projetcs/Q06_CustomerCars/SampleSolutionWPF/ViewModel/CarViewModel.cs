﻿using Newtonsoft.Json;
using SampleSolutionWPF.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace SampleSolutionWPF.ViewModel
{
    public class CarViewModel : BaseClient
    {
        private ObservableCollection<CarsModel> _items;
        public ObservableCollection<CarsModel> Items
        {
            get { return _items; }
            set
            {
                _items = value;
                OnPropertyChanged(nameof(Items));
            }
        }

        public CarViewModel()
        {
            Items = new ObservableCollection<CarsModel>();
            LoadCars();
        }

        public async void LoadCars()
        {
            try
            {
                var response = await client.GetStringAsync("cars");
                var cars = JsonConvert.DeserializeObject<ObservableCollection<CarsModel>>(response);
                Items = cars;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Unexpected error: {ex.Message}");
            }
        }

       
    }
}
