﻿using Newtonsoft.Json;
using SampleSolutionWPF.Models;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net.Http;
using System.Threading.Tasks;

namespace SampleSolutionWPF.ViewModel
{
    public class CustomerViewModel : BaseClient
    {
        private ObservableCollection<CustomersModel> _items;
     
        public ObservableCollection<CustomersModel> Items
        {
            get { return _items; }
            set
            {
                _items = value;
                OnPropertyChanged(nameof(Items));
            }
        }

        public CustomerViewModel()
        {
            Items = new ObservableCollection<CustomersModel>();
            LoadCustomers();
        }

        public async void LoadCustomers()
        {
            try
            {
                var response = await client.GetStringAsync("customers");
                var customers = JsonConvert.DeserializeObject<ObservableCollection<CustomersModel>>(response);
                Items = customers;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Unexpected error: {ex.Message}");
            }
        }

    
    }
}
