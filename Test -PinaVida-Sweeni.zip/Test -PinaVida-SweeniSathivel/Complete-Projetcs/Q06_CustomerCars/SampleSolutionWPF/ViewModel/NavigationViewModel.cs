﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using SampleSolutionWPF.Models;
using SampleSolutionWPF.View;

namespace SampleSolutionWPF.ViewModel
{
    public class NavigationViewModel : INotifyPropertyChanged
    {
        public ICommand OpenCustomerWindowCommand { get; }
        public ICommand OpenCarWindowCommand { get; }
        public ICommand OpenCustomerCarsCommand { get; }

        public NavigationViewModel()
        {
            OpenCustomerWindowCommand = new RelayCommand(_ => OpenCustomerWindow());
            OpenCarWindowCommand = new RelayCommand(_ => OpenCarWindow());
            OpenCustomerCarsCommand = new RelayCommand(_ => OpenCustomerCarsWindow());
        }

        private void OpenCustomerWindow()
        {
            Customer customerWindow = new Customer(); // Create a new Customer window
            customerWindow.Show(); // Show it as a new window
        }

        private void OpenCarWindow()
        {
            Car carWindow = new Car(); // Create a new Car window
            carWindow.Show(); // Show it as a new window
        }

        private void OpenCustomerCarsWindow()
        {
            CustomerCars customerCarWindow = new CustomerCars(); // Create a new CustomerCar window
            customerCarWindow.Show(); // Show it as a new window
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
