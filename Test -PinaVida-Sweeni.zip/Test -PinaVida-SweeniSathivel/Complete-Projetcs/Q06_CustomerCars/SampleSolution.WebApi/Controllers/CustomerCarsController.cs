﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SampleSolution.WebApi.Context;
using SampleSolution.WebApi.Model;
using System;
using System.Text.Json;

namespace SampleSolution.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
  
    public class CustomerCarsController : ControllerBase
    {
        private readonly SampleDbContext _sampleDbContext;
        public CustomerCarsController(SampleDbContext sampleDbContext)
        {
            _sampleDbContext = sampleDbContext;
        }


        // GET: api/CustomerCars
        [HttpGet]
        public async Task<IActionResult> GetCustomerCars()
        {
            var jsonData = await _sampleDbContext.GetCustomersWithCarsAsync();
            var parsedJson = JsonSerializer.Deserialize<object>(jsonData); // Parse JSON string into object
            return Ok(parsedJson);
        }
    }

    }

