﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SampleSolution.WebApi.Model;
using System;

namespace SampleSolution.WebApi.Context
{
    public class SampleDbContext : DbContext
    {
        public SampleDbContext(DbContextOptions options) : base(options)
        {
           
        }

        public DbSet<Customers> Customers { get; set; }
        public DbSet<Cars> Cars { get; set; }

        // connect database
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=VETRY\\SQLEXPRESS;Initial Catalog=CustomerCars;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
        }

        // Call stored procedure
    
        public async Task<string> GetCustomersWithCarsAsync()
        {
            string jsonResult = "[]"; // Default Json

            using (var connection = (SqlConnection)Database.GetDbConnection())
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand("EXEC CustomerCars_Select", connection))
                {
                    var reader = await command.ExecuteReaderAsync();
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync())
                        {
                            jsonResult = reader.GetString(0); // Get JSON output from stored procedure
                        }
                    }
                }
            }

            return jsonResult;
        }
    

}

}

