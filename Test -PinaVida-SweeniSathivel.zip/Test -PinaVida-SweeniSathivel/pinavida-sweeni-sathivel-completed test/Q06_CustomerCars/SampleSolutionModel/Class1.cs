﻿namespace SampleSolutionModel
{
    public class Class1
    {

    }
}
