﻿using System;

namespace Q03_ProblemSolving
{
    class Program
    {
        public static void Main(string[] args)
        {
            // Test the IsValid function with examples
            string[] testAccounts = { "82345", "12345", "98765", "54321" };

            foreach (var account in testAccounts)
            {
                bool isValid = IsValid(account);
                Console.WriteLine($"Account Number: {account} is {(isValid ? "Valid" : "Invalid")}");
            }
        }

        public static bool IsValid(string accountNumber)
        {
            // Check if account number is null or empty
            if (string.IsNullOrEmpty(accountNumber) || accountNumber.Length < 2)
            {
                return false;
            }

            // Convert account number to an array of digits
            var digits = accountNumber.Select(c => c - '0').ToArray();

            // The last digit is the check digit
            int checkDigit = digits[digits.Length - 1];

            // checksum calculation
            while (digits.Length > 1)
            {
                var newDigits = new List<int>();

                
                for (int i = 0; i < digits.Length - 1; i++)
                {
                    int sum = digits[i] + digits[i + 1];
                    newDigits.Add(sum % 10);  // Only the least significant digit
                }

                digits = newDigits.ToArray();
            }

            // The final calculated digit should match the check digit
            return digits[0] == checkDigit;
        }



    }
}
