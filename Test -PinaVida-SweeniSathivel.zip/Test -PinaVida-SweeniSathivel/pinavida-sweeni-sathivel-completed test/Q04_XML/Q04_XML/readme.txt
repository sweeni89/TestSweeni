﻿Use the sample.xml file to list all the character Names and their Age.

Only extend the "PopulateData()" method in the Program.cs.

The final result must be 4 rows/lines.

Example/Format of the Final Result:
Name (age)
Name (age)
Name (age)
Name (age)