﻿namespace Q02_Debugging
{
    class Program
    {
        static Speed s = new Speed();  // Fixed compilation error by instantiating 's'

        static void Main(string[] args)
        {
            Console.Write("KM: ");
            string km = Console.ReadLine();
            Console.Write("Hours: ");
            string hours = Console.ReadLine();

            // Check if 'km' is a valid number
            if (!double.TryParse(km, out s.km))  // If parsing fails
            {
                Console.WriteLine("Invalid input for KM");
                return;  // Stop execution if input is invalid
            }

            // Check if 'hours' is a valid number
            if (!double.TryParse(hours, out s.hours))  // If parsing fails
            {
                Console.WriteLine("Invalid input for Hours");
                return;  // Stop execution if input is invalid
            }

            // Now that we know the inputs are valid, calculate and display KPH
            Console.WriteLine("KPH: " + s.kph);
            Console.ReadKey();
        }
    }

    class Speed
    {
        public double km = 0;
        public double hours = 0;

        public double kph  // Fixed logic error by changing return type to 'double'
        {
            get
            {
                return km / hours;
            }
        }
    }
}
